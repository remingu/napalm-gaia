from setuptools import setup

setup(
    name='napalm-gaia',
    version='0.0.1',
    packages=['napalm_gaiaos', 'napalm_gaiaos.helper'],
    url='https://github.com/remingu/napalm-gaia/',
    license='Apache License 2.0',
    author='remingu, mbtathcx',
    author_email='',
    description=''
)
