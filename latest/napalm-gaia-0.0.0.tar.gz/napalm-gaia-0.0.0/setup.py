from setuptools import setup

setup(
    name='napalm-gaia',
    version='',
    packages=['napalm-gaiaos', 'napalm-gaiaos.helper'],
    url='',
    license='',
    author='remingu, mbtathcx',
    author_email='',
    description=''
)
