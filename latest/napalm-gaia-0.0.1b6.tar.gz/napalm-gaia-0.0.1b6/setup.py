from distutils.core import setup

setup(
    name='napalm-gaia',
    version='0.0.1b6',
    packages=['napalm_gaiaos', 'napalm_gaiaos.helper'],
    url='',
    license='',
    author='remingu, mbtathcx',
    author_email='',
    description=''
)
